import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView } from 'react-native';
import Slider from '@react-native-community/slider';
import { Ionicons } from '@expo/vector-icons';

import { Screen } from '@/components/Screen';
import { useSafeRouter } from '@/hooks/useSafeRouter';
import { useSettings } from '@/contexts/SettingsContext';

const ACCENT = '#8B5CF6';
const THEMES = [
  { key: 'dark', label: '深色', icon: 'moon' },
  { key: 'light', label: '浅色', icon: 'sunny' },
  { key: 'system', label: '跟随系统', icon: 'phone-portrait' },
] as const;

export default function SettingsScreen() {
  const router = useSafeRouter();
  const { settings, update } = useSettings();

  return (
    <Screen safeAreaEdges={['left', 'right', 'bottom']}>
      <View className="bg-background" style={{ flex: 1 }}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
            <Ionicons name="chevron-back" size={22} color="#d4d4d8" />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>设置</Text>
          <View style={{ width: 40 }} />
        </View>

        <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 60 }}>
          {/* 主题 */}
          <Text style={styles.sectionTitle}>外观</Text>
          <View style={styles.card}>
            <View style={styles.cardRow}>
              <Ionicons name="contrast-outline" size={18} color="#c4b5fd" />
              <Text style={styles.cardLabel}>主题模式</Text>
            </View>
            <View style={styles.themeRow}>
              {THEMES.map((t) => (
                <TouchableOpacity
                  key={t.key}
                  style={[styles.themeBtn, settings.theme === t.key && { backgroundColor: 'rgba(139,92,246,0.28)' }]}
                  onPress={() => update({ theme: t.key })}
                >
                  <Ionicons name={t.icon} size={18} color={settings.theme === t.key ? '#c4b5fd' : '#9ca3af'} />
                  <Text style={[styles.themeText, settings.theme === t.key && { color: '#c4b5fd' }]}>{t.label}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>

          {/* 歌词字号 */}
          <Text style={styles.sectionTitle}>歌词显示</Text>
          <View style={styles.card}>
            <View style={styles.fontRow}>
              <Ionicons name="text-outline" size={16} color="#c4b5fd" />
              <Text style={styles.cardLabel}>歌词字号</Text>
              <Text style={styles.fontValue}>{settings.fontSize}</Text>
            </View>
            <Slider
              style={{ width: '100%', height: 40 }}
              minimumValue={14}
              maximumValue={30}
              step={1}
              value={settings.fontSize}
              minimumTrackTintColor={ACCENT}
              maximumTrackTintColor="#3f3f46"
              thumbTintColor="#a78bfa"
              onValueChange={(v) => update({ fontSize: Math.round(v) })}
            />
          </View>

          {/* 打点行为 */}
          <Text style={styles.sectionTitle}>打轴偏好</Text>
          <View style={styles.card}>
            <ToggleRow
              icon="arrow-forward-circle"
              label="打点后自动跳到下一未打行"
              value={settings.autoAdvance}
              onChange={(v) => update({ autoAdvance: v })}
            />
            <ToggleRow
              icon="pulse"
              label="显示波形辅助对齐"
              value={settings.waveform}
              onChange={(v) => update({ waveform: v })}
            />
          </View>

          {/* 说明 */}
          <Text style={styles.sectionTitle}>关于</Text>
          <View style={styles.card}>
            <Text style={styles.about}>
              打轴小技巧：{'\n'}
              · 播到某句时点「打点」即可记录时间戳{'\n'}
              · 双指捏合波形缩放，左右滑动波形快速定位{'\n'}
              · 选中行后可 ±1s 微调，或用「偏移」整体校准{'\n'}
              · 支持 0.5x–2x 变速，慢放听清人声起落{'\n'}
              · 已打点的行会随播放自动高亮{'\n'}
              数据保存在本机，离线可用。
            </Text>
          </View>
        </ScrollView>
      </View>
    </Screen>
  );
}

function ToggleRow({ icon, label, value, onChange }: { icon: any; label: string; value: boolean; onChange: (v: boolean) => void }) {
  return (
    <TouchableOpacity style={styles.toggleRow} onPress={() => onChange(!value)}>
      <Ionicons name={icon} size={16} color="#c4b5fd" />
      <Text style={styles.cardLabel}>{label}</Text>
      <View style={[styles.switch, value && { backgroundColor: 'rgba(139,92,246,0.5)' }]}>
        <View style={[styles.switchDot, value && { transform: [{ translateX: 16 }] }]} />
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  header: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 4, paddingVertical: 8 },
  backBtn: { width: 40, padding: 8 },
  headerTitle: { flex: 1, textAlign: 'center', color: '#fafafa', fontSize: 17, fontWeight: '700' },
  sectionTitle: { color: '#a1a1aa', fontSize: 12, marginTop: 18, marginBottom: 8, paddingHorizontal: 4 },
  card: { backgroundColor: 'rgba(255,255,255,0.03)', borderRadius: 16, padding: 16, marginBottom: 6 },
  cardRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 14 },
  cardLabel: { color: '#d4d4d8', fontSize: 14, flex: 1 },
  themeRow: { flexDirection: 'row', gap: 8 },
  themeBtn: { flex: 1, alignItems: 'center', gap: 6, paddingVertical: 12, borderRadius: 12, backgroundColor: 'rgba(255,255,255,0.04)' },
  themeText: { color: '#9ca3af', fontSize: 12 },
  fontRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  fontValue: { color: '#fafafa', fontSize: 15, fontWeight: '700', fontVariant: ['tabular-nums'] },
  toggleRow: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingVertical: 10 },
  switch: { width: 40, height: 24, borderRadius: 12, backgroundColor: '#3f3f46', padding: 3, justifyContent: 'center' },
  switchDot: { width: 18, height: 18, borderRadius: 9, backgroundColor: '#fafafa' },
  about: { color: '#9ca3af', fontSize: 13, lineHeight: 24 },
});