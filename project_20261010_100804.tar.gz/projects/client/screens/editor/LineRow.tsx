import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import type { LyricLine } from '@/utils/types';
import { msToString, splitSegments } from '@/utils/timeUtil';

interface Props {
  line: LyricLine;
  index: number;
  selected: boolean;
  playing: boolean;
  fontSize: number;
  onSelect: () => void;
  onEdit: () => void;
  onDelete: () => void;
  onAddAfter: () => void;
  onAdjust: (ms: number) => void;
  onEnterWord: () => void;
  hasTranslation: boolean;
}

export function LineRow({
  line,
  index,
  selected,
  playing,
  fontSize,
  onSelect,
  onEdit,
  onDelete,
  onAddAfter,
  onAdjust,
  onEnterWord,
  hasTranslation,
}: Props) {
  const stamped = line.start >= 0;
  const wordCount = line.words && line.words.length > 0;
  const hasWordsDone = wordCount && line.words.every((w) => w.start >= 0);

  return (
    <TouchableOpacity
      onPress={onSelect}
      onLongPress={onEdit}
      delayLongPress={450}
      activeOpacity={0.6}
      style={[
        styles.row,
        selected && styles.rowSelected,
        playing && styles.rowPlaying,
      ]}
    >
      {/* 时间徽章 + 序号 */}
      <View style={styles.badgeWrap}>
        <Text style={[styles.index, selected && styles.textSelected]}>{index + 1}</Text>
        <Text
          style={[
            styles.time,
            stamped ? styles.timeSet : styles.timeEmpty,
            selected && styles.textSelected,
          ]}
        >
          {stamped ? msToString(line.start) : '--:--.--'}
        </Text>
      </View>

      {/* 文本主体 */}
      <View style={styles.textWrap}>
        <Text
          style={[
            styles.lyric,
            { fontSize },
            !line.text && styles.placeholder,
            selected && styles.textSelected,
          ]}
          numberOfLines={2}
        >
          {line.text || '(空白行·点击打点)'}
        </Text>
        {hasTranslation && line.translation ? (
          <Text style={styles.translation} numberOfLines={2}>
            {line.translation}
          </Text>
        ) : null}
        {wordCount ? (
          <Text style={styles.wordHint}>
            逐字已标 {hasWordsDone ? '✓' : '…'}
          </Text>
        ) : null}
      </View>

      {/* 操作按钮 */}
      {selected && (
        <View style={styles.actions}>
          <TouchableOpacity style={styles.iconBtn} onPress={() => onAdjust(-1000)}>
            <Ionicons name="remove" size={14} color="#F59E0B" />
          </TouchableOpacity>
          <TouchableOpacity style={styles.iconBtn} onPress={() => onAdjust(1000)}>
            <Ionicons name="add" size={14} color="#F59E0B" />
          </TouchableOpacity>
          <TouchableOpacity style={styles.iconBtn} onPress={onEnterWord}>
            <Ionicons name="text" size={14} color="#a78bfa" />
          </TouchableOpacity>
          <TouchableOpacity style={styles.iconBtn} onPress={onAddAfter}>
            <Ionicons name="add-circle-outline" size={16} color="#4b5563" />
          </TouchableOpacity>
          <TouchableOpacity style={styles.iconBtn} onPress={onEdit}>
            <Ionicons name="create-outline" size={16} color="#4b5563" />
          </TouchableOpacity>
          <TouchableOpacity style={styles.iconBtn} onPress={onDelete}>
            <Ionicons name="trash-outline" size={15} color="#f87171" />
          </TouchableOpacity>
        </View>
      )}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.03)',
    borderRadius: 12,
    paddingVertical: 8,
    paddingHorizontal: 10,
    marginHorizontal: 12,
    marginVertical: 3,
    borderLeftWidth: 3,
    borderLeftColor: 'transparent',
  },
  rowSelected: {
    borderLeftColor: '#8B5CF6',
    backgroundColor: 'rgba(139,92,246,0.12)',
  },
  rowPlaying: {
    borderLeftColor: '#F59E0B',
    backgroundColor: 'rgba(245,158,11,0.10)',
  },
  badgeWrap: { width: 62, alignItems: 'center' },
  index: { fontSize: 11, color: '#6b7280' },
  time: { fontSize: 12, fontVariant: ['tabular-nums'], marginTop: 2, letterSpacing: 0.2 },
  timeSet: { color: '#F59E0B' },
  timeEmpty: { color: '#52525b' },
  textSelected: { color: '#ffffff' },
  textWrap: { flex: 1, paddingHorizontal: 4 },
  lyric: { color: '#e4e4e7', lineHeight: 26, fontWeight: '500' },
  placeholder: { color: '#52525b', fontStyle: 'italic' },
  translation: { color: '#9ca3af', fontSize: 13, marginTop: 2, lineHeight: 18 },
  wordHint: { color: '#a78bfa', fontSize: 10, marginTop: 2 },
  actions: { flexDirection: 'row', alignItems: 'center', marginLeft: 2, flexWrap: 'wrap', maxWidth: 118 },
  iconBtn: { padding: 6, marginLeft: 2 },
});

export { splitSegments };