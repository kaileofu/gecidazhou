import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  TextInput,
  FlatList,
  Modal,
  StyleSheet,
  ScrollView,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import * as DocumentPicker from 'expo-document-picker';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { Screen } from '@/components/Screen';
import { useSafeRouter, useSafeSearchParams } from '@/hooks/useSafeRouter';
import { useAudioPlayer } from '@/hooks/useAudioPlayer';
import { useProjectEditor } from '@/hooks/useProjectEditor';
import { useSettings } from '@/contexts/SettingsContext';
import { WaveformView } from '@/components/WaveformView';
import { LineRow } from '@/screens/editor/LineRow';

import type { Project, LyricLine, ProjectMeta } from '@/utils/types';
import { makeLine, makeProject } from '@/utils/types';
import { msToString, splitSegments } from '@/utils/timeUtil';
import { parseLyrics, toLrc, toSrt, toAss, toTxt } from '@/utils/lrcUtil';
import { shareTextFile, readClipboard } from '@/utils/exportUtil';
import { loadProjectById, saveProject } from '@/utils/projectStore';

const RATES = [0.5, 0.75, 1, 1.25, 1.5, 2];
const ACCENT = '#8B5CF6';
const AMBER = '#F59E0B';

const ignoreErr = (e: unknown) => {
  if (__DEV__) console.debug('[editor]', e);
};

export default function EditorScreen() {
  const router = useSafeRouter();
  const params = useSafeSearchParams<{ projectId?: string }>();
  const { settings } = useSettings();
  const insets = useSafeAreaInsets();

  const [project, setProject] = useState<Project | null>(null);
  const projectRef = useRef<Project | null>(null);
  const [ready, setReady] = useState(false);

  const { lines, pastCount, futureCount, reset, commit, undo, redo } = useProjectEditor([]);
  const [selectedId, setSelectedId] = useState<string | undefined>(undefined);
  const selectedRef = useRef<string | undefined>(undefined);
  selectedRef.current = selectedId;
  const [wordModeId, setWordModeId] = useState<string | null>(null);

  const player = useAudioPlayer();

  const [editLine, setEditLine] = useState<LyricLine | null>(null);
  const [showImport, setShowImport] = useState(false);
  const [showExport, setShowExport] = useState(false);
  const [showMeta, setShowMeta] = useState(false);
  const [showOffset, setShowOffset] = useState(false);

  const applyProject = useCallback((p: Project) => {
    projectRef.current = p;
    setProject(p);
    reset(p.lines);
    setSelectedId(p.activeLineId ?? p.lines[0]?.id);
    setReady(true);
  }, [reset]);

  // 初始化工程
  useEffect(() => {
    (async () => {
      if (params.projectId) {
        const p = await loadProjectById(params.projectId);
        if (p) {
          applyProject(p);
          return;
        }
      }
      // 无 id 或未找到：新建
      const np = makeProject();
      np.activeLineId = undefined;
      await saveProject(np);
      applyProject(np);
    })();
  }, [params.projectId, applyProject]);

  // 载入音频
  useEffect(() => {
    if (project?.audioUri && project.audioUri !== player.loadedUri) {
      player.load(project.audioUri);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [project?.audioUri]);

  // 持久化（lines 变化时）
  useEffect(() => {
    if (!projectRef.current) return;
    const np: Project = { ...projectRef.current, lines, updatedAt: Date.now(), activeLineId: selectedRef.current };
    projectRef.current = np;
    setProject(np);
    saveProject(np).catch(ignoreErr);
  }, [lines]);

  // 卸载时保存音频 uri 变化（由 load 流程调用 saveProjectUri 处理）

  // 播放位置对应的当前行
  const playingIdx = useMemo(() => {
    let idx = -1;
    for (let i = 0; i < lines.length; i++) {
      if (lines[i].start >= 0 && lines[i].start <= player.position + 200) idx = i;
      else if (lines[i].start > player.position + 200) break;
    }
    return idx;
  }, [lines, player.position]);

  const selectedLine = useMemo(() => lines.find((l) => l.id === selectedId), [lines, selectedId]);

  // ------- 行操作 -------
  const updateMeta = useCallback((patch: Partial<ProjectMeta>) => {
    if (!projectRef.current) return;
    const np = { ...projectRef.current, meta: { ...projectRef.current.meta, ...patch }, updatedAt: Date.now() };
    projectRef.current = np;
    setProject(np);
    saveProject(np).catch(ignoreErr);
  }, []);

  const setAudio = useCallback((uri: string | undefined, name?: string) => {
    if (!projectRef.current) return;
    const np = { ...projectRef.current, audioUri: uri, audioName: name, updatedAt: Date.now() };
    projectRef.current = np;
    setProject(np);
    saveProject(np).catch(ignoreErr);
    if (uri) player.load(uri);
  }, [player]);

  const handleAddLine = useCallback((afterIndex?: number | undefined) => {
    const line = makeLine('');
    commit((ls) => {
      if (afterIndex != null && afterIndex >= 0) {
        const copy = [...ls];
        copy.splice(afterIndex + 1, 0, line);
        return copy;
      }
      return [...ls, line];
    });
    setSelectedId(line.id);
    setWordModeId(null);
  }, [commit]);

  // 打点：主按钮
  const stamp = useCallback(() => {
    const targetId = wordModeId ?? selectedRef.current;
    const line = lines.find((l) => l.id === targetId);

    if (wordModeId) {
      if (!line) { setWordModeId(null); return; }
      const nextWord = line.words.find((w) => w.start < 0);
      if (!nextWord) { setWordModeId(null); return; }
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(ignoreErr);
      commit((ls) =>
        ls.map((l) =>
          l.id === line.id
            ? { ...l, words: l.words.map((w) => (w === nextWord ? { ...w, start: player.position } : w)) }
            : l
        )
      );
      return;
    }

    // 普通模式：给目标行打点（无目标则选第一个未打/首行）
    const target = line ?? lines.find((l) => l.start < 0) ?? lines[0];
    if (!target) return;
    const wasUnset = target.start < 0;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium).catch(ignoreErr);
    commit((ls) => ls.map((l) => (l.id === target.id ? { ...l, start: player.position } : l)));
    setSelectedId(target.id);
    if (wasUnset && settings.autoAdvance) {
      const idx = lines.findIndex((l) => l.id === target.id);
      const nextUnset = lines.findIndex((l, i) => i > idx && l.start < 0 && l.text.trim());
      if (nextUnset >= 0) setSelectedId(lines[nextUnset].id);
    }
  }, [lines, commit, player.position, settings.autoAdvance, wordModeId]);

  const adjust = useCallback((lineId: string, deltaMs: number) => {
    commit((ls) => ls.map((l) => (l.id === lineId ? { ...l, start: Math.max(0, l.start + deltaMs) } : l)));
  }, [commit]);

  const deleteLine = useCallback((lineId: string) => {
    commit((ls) => ls.filter((l) => l.id !== lineId));
    if (selectedId === lineId) setSelectedId(undefined);
  }, [commit, selectedId]);

  const enterWordMode = useCallback((lineId: string) => {
    commit((ls) =>
      ls.map((l) =>
        l.id === lineId
          ? {
              ...l,
              words: splitSegments(l.text).map((t) => ({ text: t, start: -1, duration: -1 })),
            }
          : l
      )
    );
    setWordModeId(lineId);
  }, [commit]);

  // 合并到上一行
  const mergeUp = useCallback(() => {
    if (!selectedId) return;
    const idx = lines.findIndex((l) => l.id === selectedId);
    if (idx <= 0) return;
    commit((ls) => {
      const copy = [...ls];
      const prev = copy[idx - 1];
      copy[idx - 1] = { ...prev, text: (prev.text + ' ' + copy[idx].text).trim() };
      copy.splice(idx, 1);
      return copy;
    });
    setWordModeId(null);
  }, [selectedId, lines, commit]);

  // 拆分当前行（在最近空格中点）
  const splitLine = useCallback(() => {
    if (!selectedId) return;
    const line = lines.find((l) => l.id === selectedId);
    if (!line || !line.text) return;
    const t = line.text.trim();
    const mid = Math.floor(t.length / 2);
    // 找最近空格
    let cut = t.length;
    for (let i = mid; i < t.length; i++) if (t[i] === ' ' || t[i] === '，' || t[i] === '，') { cut = i; break; }
    if (cut >= t.length) return;
    const head = t.slice(0, cut).trim();
    const tail = t.slice(cut).trim();
    if (!head || !tail) return;
    const newLine = makeLine(tail, line.start >= 0 ? line.start + 1500 : -1);
    commit((ls) => {
      const copy = [...ls];
      const idx = copy.findIndex((l) => l.id === selectedId);
      copy[idx] = { ...copy[idx], text: head };
      copy.splice(idx + 1, 0, newLine);
      return copy;
    });
    setSelectedId(newLine.id);
  }, [selectedId, lines, commit]);

  // 整体偏移
  const applyOffset = useCallback((ms: number) => {
    commit((ls) =>
      ls.map((l) => ({
        ...l,
        start: l.start >= 0 ? Math.max(0, l.start + ms) : l.start,
        words: l.words.map((w) => (w.start >= 0 ? { ...w, start: Math.max(0, w.start + ms) } : w)),
      }))
    );
  }, [commit]);

  // 自动均分打轴（按文本长度比例）
  const autoAxis = useCallback(() => {
    const dur = projectRef.current?.audioDuration || player.duration || 0;
    if (dur <= 0) {
      Alert.alert('提示', '请先导入音频，用于估算时长');
      return;
    }
    const voiced = lines.filter((l) => l.text.trim());
    if (voiced.length === 0) return;
    const totalLen = voiced.reduce((s, l) => s + l.text.replace(/\s/g, '').length + 1, 0);
    let cursor = 0;
    const starts = voiced.map((l) => {
      const w = l.text.replace(/\s/g, '').length + 1;
      const durPart = (w / totalLen) * dur * 0.92;
      const start = cursor;
      cursor += durPart;
      return { id: l.id, start };
    });
    commit((ls) => ls.map((l) => {
      const m = starts.find((s) => s.id === l.id);
      return m ? { ...l, start: Math.round(m.start) } : l;
    }));
    Alert.alert('已生成初稿', '时间已按文本长度均分，请结合波形微调。');
  }, [lines, commit, player.duration]);

  // 导入音频
  const pickAudio = useCallback(async () => {
    try {
      const res = await DocumentPicker.getDocumentAsync({
        type: ['audio/*'],
        copyToCacheDirectory: false,
        multiple: false,
      });
      if (res.canceled || res.assets.length === 0) return;
      const asset = res.assets[0];
      setAudio(asset.uri, asset.name);
    } catch (e) {
      Alert.alert('导入失败', e instanceof Error ? e.message : '无法读取音频');
    }
  }, [setAudio]);

  // ------- 渲染 -------
  if (!ready || !project) {
    return (
      <Screen>
        <View className="flex-1 items-center justify-center" style={{ minHeight: 200 }}>
          <Text className="text-muted">加载中…</Text>
        </View>
      </Screen>
    );
  }

  const title = project.meta.title || project.audioName || '未命名工程';

  return (
    <Screen safeAreaEdges={['left', 'right', 'bottom']}>
      <View style={{ flex: 1 }} className="bg-background">
        {/* 顶部工具条 */}
        <View style={[styles.toolbar, { paddingTop: insets.top + 8 }]}>
          <TouchableOpacity onPress={() => router.back()} style={styles.toolBtn}>
            <Ionicons name="chevron-back" size={22} color="#d4d4d8" />
          </TouchableOpacity>
          <Text style={styles.title} numberOfLines={1}>{title}</Text>
          <TouchableOpacity onPress={pickAudio} style={styles.toolBtn}>
            <Ionicons name="musical-notes" size={18} color="#a78bfa" />
          </TouchableOpacity>
          <TouchableOpacity onPress={() => setShowImport(true)} style={styles.toolBtn}>
            <Ionicons name="download-outline" size={18} color="#a78bfa" />
          </TouchableOpacity>
          <TouchableOpacity onPress={() => setShowExport(true)} style={styles.toolBtn}>
            <Ionicons name="share-outline" size={18} color="#a78bfa" />
          </TouchableOpacity>
        </View>

        {/* 波形 + 时间 */}
        <View style={styles.waveWrap}>
          <WaveformView
            durationMs={project.audioDuration || player.duration || 1}
            positionMs={player.position}
            markers={lines.map((l) => ({ start: l.start, isSet: l.start >= 0 }))}
            onSeek={(ms) => player.seek(ms)}
            height={88}
          />
          <View style={styles.timerRow}>
            <Text style={styles.timer}>{msToString(player.position)}</Text>
            <Text style={styles.timerTotal}>/ {msToString(player.duration || project.audioDuration)}</Text>
          </View>
        </View>

        {/* 歌词列表 */}
        <FlatList
          data={lines}
          keyExtractor={(l) => l.id}
          style={{ flex: 1 }}
          contentContainerStyle={{ paddingVertical: 4, paddingBottom: 12 }}
          extraData={{ selectedId, playingIdx, wordModeId }}
          keyboardShouldPersistTaps="handled"
          ListEmptyComponent={
            <View style={{ padding: 32, alignItems: 'center' }}>
              <Ionicons name="albums-outline" size={40} color="#3f3f46" />
              <Text style={styles.emptyText}>还没有歌词</Text>
              <Text style={styles.emptySub}>点右上角「下载」导入 LRC/SRT，或添加空白行后边播边打点</Text>
            </View>
          }
          renderItem={({ item, index }) => (
            <LineRow
              line={item}
              index={index}
              selected={item.id === selectedId && wordModeId === null}
              playing={index === playingIdx}
              fontSize={settings.fontSize}
              hasTranslation={!!item.translation}
              onSelect={() => {
                setSelectedId(item.id);
                setWordModeId(null);
              }}
              onEdit={() => setEditLine(item)}
              onDelete={() => deleteLine(item.id)}
              onAddAfter={() => handleAddLine(index)}
              onAdjust={(d) => adjust(item.id, d)}
              onEnterWord={() => enterWordMode(item.id)}
            />
          )}
        />

        {/* 变速 + 微调 + 撤销 底部栏 */}
        <View style={styles.bottomBar}>
          <View style={styles.rateRow}>
            {RATES.map((r) => (
              <TouchableOpacity
                key={r}
                onPress={() => player.setRate(r)}
                style={[styles.rateChip, player.rate === r && { backgroundColor: 'rgba(139,92,246,0.35)' }]}
              >
                <Text style={[styles.rateText, player.rate === r && { color: '#c4b5fd' }]}>{r}x</Text>
              </TouchableOpacity>
            ))}
          </View>
          <View style={styles.smallRow}>
            <TouchableOpacity
              style={[styles.smallBtn, { opacity: pastCount ? 1 : 0.3 }]}
              disabled={!pastCount}
              onPress={undo}
            >
              <Ionicons name="arrow-undo" size={16} color="#e4e4e7" />
              <Text style={styles.smallBtnText}>撤销</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.smallBtn, { opacity: futureCount ? 1 : 0.3 }]}
              disabled={!futureCount}
              onPress={redo}
            >
              <Ionicons name="arrow-redo" size={16} color="#e4e4e7" />
              <Text style={styles.smallBtnText}>重做</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.smallBtn} onPress={() => setShowOffset(true)}>
              <Ionicons name="swap-horizontal" size={16} color="#e4e4e7" />
              <Text style={styles.smallBtnText}>偏移</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.smallBtn} onPress={() => setShowMeta(true)}>
              <Ionicons name="information-circle-outline" size={16} color="#e4e4e7" />
              <Text style={styles.smallBtnText}>元数据</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.smallBtn} onPress={autoAxis}>
              <Ionicons name="flash-outline" size={16} color="#F59E0B" />
              <Text style={styles.smallBtnText}>自动</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* 悬浮播放/逐字 提示条 与 大打点按钮 */}
        <View style={styles.stampCluster}>
          <TouchableOpacity
            onPress={player.toggle}
            style={[styles.pauseFloating, { backgroundColor: 'rgba(20,20,28,0.9)' }]}
          >
            <Ionicons name={player.isPlaying ? 'pause' : 'play'} size={26} color="#ffffff" />
          </TouchableOpacity>
          <TouchableOpacity onPress={stamp} style={styles.bigStamp} activeOpacity={0.75}>
            <Ionicons name="flag" size={34} color="#1c1917" />
            <Text style={styles.bigStampText}>打点</Text>
          </TouchableOpacity>
        </View>

        {wordModeId ? (
          <View style={styles.wordBanner}>
            <TouchableOpacity style={styles.wordBannerClose} onPress={() => setWordModeId(null)}>
              <Ionicons name="close" size={14} color="#fff" />
            </TouchableOpacity>
            <Text style={styles.wordBannerText}>
              逐字模式 · 播到每个字起点时点「打点」 · 已标{' '}
              {lines.find((l) => l.id === wordModeId)?.words.filter((w) => w.start >= 0).length ?? 0}/
              {lines.find((l) => l.id === wordModeId)?.words.length ?? 0}
            </Text>
          </View>
        ) : null}

        {/* 当前行逐字预览 */}
        {wordModeId && selectedLine ? (
          <ClickableWords line={selectedLine} position={player.position} />
        ) : null}
      </View>

      {/* Modals */}
      <EditLineModal
        line={editLine}
        onClose={() => setEditLine(null)}
        onSave={(updated) => {
          commit((ls) => ls.map((l) => (l.id === updated.id ? updated : l)));
          setEditLine(null);
        }}
      />
      <ImportModal
        visible={showImport}
        onClose={() => setShowImport(false)}
        onApply={(parsedLines, metaPatch) => {
          commit(() => parsedLines);
          updateMeta(metaPatch);
          setSelectedId(parsedLines[0]?.id);
          setShowImport(false);
        }}
      />
      <ExportModal
        visible={showExport}
        project={project}
        onClose={() => setShowExport(false)}
      />
      <MetaModal
        visible={showMeta}
        meta={project.meta}
        audioName={project.audioName}
        onClose={() => setShowMeta(false)}
        onSave={(patch) => {
          updateMeta(patch);
          setShowMeta(false);
        }}
        onImportAudio={pickAudio}
      />
      <OffsetModal
        visible={showOffset}
        onClose={() => setShowOffset(false)}
        onApply={(ms) => {
          applyOffset(ms);
          setShowOffset(false);
        }}
      />
    </Screen>
  );
}

// ======= 可点击逐字高亮预览 =======
function ClickableWords({ line, position }: { line: LyricLine; position: number }) {
  const words = line.words;
  if (!words || words.length === 0) return null;
  return (
    <View style={styles.clickWordsWrap}>
      {words.map((w, i) => {
        const active = w.start >= 0 && position >= w.start && position < (words[i + 1]?.start ?? position + 1);
        return (
          <Text key={i} style={[styles.clickWord, w.start >= 0 && { color: '#F59E0B' }, active && styles.clickWordActive]}>
            {w.text}
          </Text>
        );
      })}
    </View>
  );
}

// ======= 编辑行弹窗 =======
function EditLineModal({
  line,
  onClose,
  onSave,
}: {
  line: LyricLine | null;
  onClose: () => void;
  onSave: (l: LyricLine) => void;
}) {
  return (
    <Modal visible={!!line} transparent animationType="slide" onRequestClose={onClose}>
      {line ? (
        <EditLineBody
          key={`${line.id}:${line.text}:${line.translation}`}
          line={line}
          onClose={onClose}
          onSave={onSave}
        />
      ) : null}
    </Modal>
  );
}

function EditLineBody({
  line,
  onClose,
  onSave,
}: {
  line: LyricLine;
  onClose: () => void;
  onSave: (l: LyricLine) => void;
}) {
  const [text, setText] = useState(line.text);
  const [trans, setTrans] = useState(line.translation);
  const [start, setStart] = useState(line.start >= 0 ? String(line.start) : '');

  return (
    <View style={styles.modalMask}>
      <View style={styles.modalCard}>
        <View style={styles.modalHeader}>
          <Text style={styles.modalTitle}>编辑歌词行</Text>
          <TouchableOpacity onPress={onClose}><Ionicons name="close" size={22} color="#a1a1aa" /></TouchableOpacity>
        </View>
        <ScrollView keyboardShouldPersistTaps="handled">
          <Text style={styles.label}>原文</Text>
          <TextInput
            style={styles.input}
            value={text}
            onChangeText={setText}
            multiline
            placeholder="输入这一句歌词"
            placeholderTextColor="#52525b"
          />
          <Text style={styles.label}>翻译（可选）</Text>
          <TextInput
            style={styles.input}
            value={trans}
            onChangeText={setTrans}
            multiline
            placeholder="翻译文本"
            placeholderTextColor="#52525b"
          />
          <Text style={styles.label}>起始时间（毫秒，留空=未打点）</Text>
          <TextInput
            style={styles.input}
            value={start}
            onChangeText={setStart}
            keyboardType="number-pad"
            placeholder="如 12000"
            placeholderTextColor="#52525b"
          />
        </ScrollView>
        <View style={styles.modalFooter}>
          <TouchableOpacity style={[styles.footerBtn, { backgroundColor: 'rgba(255,255,255,0.08)' }]} onPress={onClose}>
            <Text style={styles.footerBtnTextMuted}>取消</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.footerBtn, { backgroundColor: ACCENT }]}
            onPress={() => {
              const ms = start.trim() === '' ? -1 : Math.max(-1, parseInt(start, 10) || -1);
              onSave({ ...line, text, translation: trans, start: ms });
            }}
          >
            <Text style={styles.footerBtnText}>保存</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

// ======= 导入弹窗 =======
function ImportModal({
  visible,
  onClose,
  onApply,
}: {
  visible: boolean;
  onClose: () => void;
  onApply: (lines: LyricLine[], meta: Partial<ProjectMeta>) => void;
}) {
  const [textIn, setTextIn] = useState('');
  const doApply = () => {
    if (!textIn.trim()) { Alert.alert('提示', '请先粘贴歌词文本'); return; }
    try {
      const { lines, meta } = parseLyrics(textIn);
      if (lines.length === 0) { Alert.alert('提示', '未能解析出任何歌词行'); return; }
      onApply(lines, meta);
    } catch {
      Alert.alert('解析失败', '请检查文本格式');
    }
  };
  const pasteClip = async () => {
    const t = await readClipboard();
    if (t) setTextIn(t);
    else Alert.alert('提示', '剪贴板为空');
  };
  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <View style={styles.modalMask}>
        <View style={styles.modalCard}>
          <View style={styles.modalHeader}>
            <Text style={styles.modalTitle}>导入歌词</Text>
            <TouchableOpacity onPress={onClose}><Ionicons name="close" size={22} color="#a1a1aa" /></TouchableOpacity>
          </View>
          <View style={styles.importHints}>
            <TouchableOpacity style={styles.hintChip} onPress={pasteClip}>
              <Ionicons name="clipboard-outline" size={14} color="#c4b5fd" />
              <Text style={styles.hintChipText}>从剪贴板粘贴</Text>
            </TouchableOpacity>
            <View style={styles.hintInfo}>
              <Text style={styles.hintInfoText}>支持 LRC / SRT / 纯文本，自动识别并解析时间轴与元数据</Text>
            </View>
          </View>
          <TextInput
            style={[styles.input, { minHeight: 220, textAlignVertical: 'top' }]}
            value={textIn}
            onChangeText={setTextIn}
            multiline
            placeholder={'在此粘贴歌词…\n\n例如：[00:12.50]第一句\n[00:16.00]第二句'}
            placeholderTextColor="#52525b"
          />
          <View style={styles.modalFooter}>
            <TouchableOpacity style={[styles.footerBtn, { backgroundColor: 'rgba(255,255,255,0.08)' }]} onPress={onClose}>
              <Text style={styles.footerBtnTextMuted}>取消</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[styles.footerBtn, { backgroundColor: ACCENT }]} onPress={doApply}>
              <Text style={styles.footerBtnText}>解析并导入</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
}

// ======= 导出弹窗 =======
function ExportModal({ visible, project, onClose }: { visible: boolean; project: Project; onClose: () => void }) {
  const opts = [
    { key: 'lrc', label: 'LRC', desc: '标准歌词（含翻译行）', gen: () => toLrc(project.lines, project.meta) },
    { key: 'elrc', label: 'LRC 增强', desc: '含逐字时间轴（KTV）', gen: () => toLrc(project.lines, project.meta, { enhanced: true }) },
    { key: 'srt', label: 'SRT', desc: '字幕格式（含时长）', gen: () => toSrt(project.lines) },
    { key: 'ass', label: 'ASS', desc: '高级字幕（K 歌特效预留）', gen: () => toAss(project.lines, project.meta) },
    { key: 'txt', label: 'TXT', desc: '纯文本（带时间）', gen: () => toTxt(project.lines, true) },
  ];
  const doExport = async (o: (typeof opts)[number]) => {
    const content = o.gen();
    const base = project.meta.title || project.audioName || 'lyrics';
    const ext = o.key === 'elrc' ? 'lrc' : o.key;
    const filename = `${base}.${ext}`;
    const res = await shareTextFile(filename, content, 'text/plain');
    if (res.msg) Alert.alert('提示', res.msg);
  };
  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <View style={styles.modalMask}>
        <View style={styles.modalCard}>
          <View style={styles.modalHeader}>
            <Text style={styles.modalTitle}>导出 / 分享</Text>
            <TouchableOpacity onPress={onClose}><Ionicons name="close" size={22} color="#a1a1aa" /></TouchableOpacity>
          </View>
          <ScrollView>
            {opts.map((o) => (
              <TouchableOpacity key={o.key} style={styles.exportRow} onPress={() => doExport(o)}>
                <View style={{ flex: 1 }}>
                  <Text style={styles.exportLabel}>{o.label}</Text>
                  <Text style={styles.exportDesc}>{o.desc}</Text>
                </View>
                <Ionicons name="share-outline" size={18} color="#a78bfa" />
              </TouchableOpacity>
            ))}
            <Text style={styles.exportTip}>选择格式后即可分享到微信、QQ、网盘等。</Text>
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

// ======= 元数据弹窗 =======
function MetaModal({
  visible,
  meta,
  audioName,
  onClose,
  onSave,
  onImportAudio,
}: {
  visible: boolean;
  meta: ProjectMeta;
  audioName?: string;
  onClose: () => void;
  onSave: (p: Partial<ProjectMeta>) => void;
  onImportAudio: () => void;
}) {
  const [title, setTitle] = useState('');
  const [artist, setArtist] = useState('');
  const [album, setAlbum] = useState('');
  const [offset, setOffset] = useState('0');
  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      {visible ? (
        <MetaBody
          key={audioName || JSON.stringify(meta)}
          meta={meta}
          audioName={audioName}
          onClose={onClose}
          onSave={onSave}
          onImportAudio={onImportAudio}
        />
      ) : null}
    </Modal>
  );
}

function MetaBody({
  meta,
  audioName,
  onClose,
  onSave,
  onImportAudio,
}: {
  meta: ProjectMeta;
  audioName?: string;
  onClose: () => void;
  onSave: (p: Partial<ProjectMeta>) => void;
  onImportAudio: () => void;
}) {
  const [title, setTitle] = useState(meta.title);
  const [artist, setArtist] = useState(meta.artist);
  const [album, setAlbum] = useState(meta.album);
  const [offset, setOffset] = useState(String(meta.offset));
  return (
    <View style={styles.modalMask}>
      <View style={styles.modalCard}>
        <View style={styles.modalHeader}>
          <Text style={styles.modalTitle}>元数据</Text>
          <TouchableOpacity onPress={onClose}><Ionicons name="close" size={22} color="#a1a1aa" /></TouchableOpacity>
        </View>
          <ScrollView keyboardShouldPersistTaps="handled">
            <TouchableOpacity style={styles.audioRow} onPress={onImportAudio}>
              <Ionicons name="musical-note" size={18} color={audioName ? '#34d399' : '#52525b'} />
              <Text style={styles.audioName} numberOfLines={1}>
                {audioName || '导入音频 (mp3/m4a/wav…)'}
              </Text>
            </TouchableOpacity>
            <InputRow label="歌名" value={title} onChange={setTitle} ph="《…》" />
            <InputRow label="歌手" value={artist} onChange={setArtist} ph="歌手名" />
            <InputRow label="专辑" value={album} onChange={setAlbum} ph="专辑名" />
            <InputRow label="偏移量(ms)" value={offset} onChange={setOffset} ph="正数=整体后移" numeric />
          </ScrollView>
          <View style={styles.modalFooter}>
            <TouchableOpacity style={[styles.footerBtn, { backgroundColor: 'rgba(255,255,255,0.08)' }]} onPress={onClose}>
              <Text style={styles.footerBtnTextMuted}>取消</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.footerBtn, { backgroundColor: ACCENT }]}
              onPress={() => onSave({ title, artist, album, offset: parseInt(offset, 10) || 0 })}
            >
              <Text style={styles.footerBtnText}>保存</Text>
            </TouchableOpacity>
          </View>
        </View>
    </View>
  );
}

function InputRow({ label, value, onChange, ph, numeric }: { label: string; value: string; onChange: (s: string) => void; ph?: string; numeric?: boolean }) {
  return (
    <View style={{ marginBottom: 12 }}>
      <Text style={styles.label}>{label}</Text>
      <TextInput
        style={styles.input}
        value={value}
        onChangeText={onChange}
        placeholder={ph}
        placeholderTextColor="#52525b"
        keyboardType={numeric ? 'numbers-and-punctuation' : 'default'}
      />
    </View>
  );
}

// ======= 整体偏移弹窗 =======
function OffsetModal({ visible, onClose, onApply }: { visible: boolean; onClose: () => void; onApply: (ms: number) => void }) {
  const [ms, setMs] = useState('0');
  const [dir, setDir] = useState<1 | -1>(1);
  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <View style={styles.modalMask}>
        <View style={styles.modalCard}>
          <View style={styles.modalHeader}>
            <Text style={styles.modalTitle}>整体偏移</Text>
            <TouchableOpacity onPress={onClose}><Ionicons name="close" size={22} color="#a1a1aa" /></TouchableOpacity>
          </View>
          <View style={styles.dirRow}>
            <TouchableOpacity style={[styles.dirBtn, dir === -1 && { backgroundColor: 'rgba(139,92,246,0.35)' }]} onPress={() => setDir(-1)}>
              <Text style={styles.dirText}>提前</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[styles.dirBtn, dir === 1 && { backgroundColor: 'rgba(139,92,246,0.35)' }]} onPress={() => setDir(1)}>
              <Text style={styles.dirText}>滞后</Text>
            </TouchableOpacity>
          </View>
          <TextInput style={[styles.input, { textAlign: 'center', fontSize: 22 }]} value={ms} onChangeText={(t) => setMs(t.replace(/\D/g, ''))} keyboardType="number-pad" placeholder="毫秒" placeholderTextColor="#52525b" />
          <Text style={styles.offsetTip}>对所有已打点的行（及逐字）统一 {dir === 1 ? '加' : '减'} 该毫秒数，用于修正整体延迟。</Text>
          <View style={styles.modalFooter}>
            <TouchableOpacity style={[styles.footerBtn, { backgroundColor: 'rgba(255,255,255,0.08)' }]} onPress={onClose}>
              <Text style={styles.footerBtnTextMuted}>取消</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[styles.footerBtn, { backgroundColor: AMBER }]} onPress={() => onApply(dir * (parseInt(ms, 10) || 0))}>
              <Text style={styles.footerBtnText}>应用</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
}

// ======= 样式 =======
const styles = StyleSheet.create({
  toolbar: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 6, paddingVertical: 8, gap: 2 },
  toolBtn: { padding: 8 },
  title: { flex: 1, color: '#fafafa', fontWeight: '700', fontSize: 16, paddingHorizontal: 4 },
  waveWrap: { paddingHorizontal: 6, paddingBottom: 2 },
  timerRow: { flexDirection: 'row', paddingHorizontal: 12, paddingTop: 6 },
  timer: { color: AMBER, fontVariant: ['tabular-nums'], fontWeight: '700', fontSize: 15 },
  timerTotal: { color: '#71717a', fontVariant: ['tabular-nums'], fontSize: 13, marginTop: 2 },
  emptyText: { color: '#71717a', marginTop: 12, fontSize: 15 },
  emptySub: { color: '#3f3f46', textAlign: 'center', marginTop: 6, fontSize: 13, lineHeight: 20, paddingHorizontal: 40 },
  bottomBar: { paddingHorizontal: 10, paddingVertical: 8, borderTopWidth: 1, borderTopColor: 'rgba(255,255,255,0.06)' },
  rateRow: { flexDirection: 'row', justifyContent: 'center', gap: 8, marginBottom: 8 },
  rateChip: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 20, backgroundColor: 'rgba(255,255,255,0.05)' },
  rateText: { color: '#a1a1aa', fontWeight: '600', fontSize: 13 },
  smallRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  smallBtn: { flexDirection: 'row', alignItems: 'center', paddingVertical: 6, paddingHorizontal: 4, gap: 4 },
  smallBtnText: { color: '#d4d4d8', fontSize: 12 },
  stampCluster: { position: 'absolute', right: 16, bottom: 118, alignItems: 'center' },
  pauseFloating: { width: 52, height: 52, borderRadius: 26, alignItems: 'center', justifyContent: 'center', marginBottom: 12, shadowColor: '#000', shadowOpacity: 0.4, shadowRadius: 12, shadowOffset: { width: 0, height: 4 }, elevation: 8 },
  bigStamp: { width: 96, height: 96, borderRadius: 48, backgroundColor: AMBER, alignItems: 'center', justifyContent: 'center', shadowColor: '#F59E0B', shadowOpacity: 0.5, shadowRadius: 22, shadowOffset: { width: 0, height: 8 }, elevation: 12 },
  bigStampText: { color: '#1c1917', fontWeight: '800', fontSize: 14, marginTop: 2 },
  wordBanner: { position: 'absolute', left: 12, right: 12, bottom: 12, backgroundColor: 'rgba(139,92,246,0.25)', borderRadius: 12, padding: 10, flexDirection: 'row', alignItems: 'center' },
  wordBannerClose: { marginRight: 8 },
  wordBannerText: { color: '#e9d5ff', fontSize: 12, flex: 1 },
  clickWordsWrap: { position: 'absolute', left: 12, right: 90, bottom: 56, flexDirection: 'row', flexWrap: 'wrap', backgroundColor: 'rgba(0,0,0,0.55)', borderRadius: 10, padding: 8 },
  clickWord: { color: '#9ca3af', fontSize: 20, fontWeight: '700', marginRight: 2 },
  clickWordActive: { color: '#FBBF24' },
  modalMask: { flex: 1, backgroundColor: 'rgba(0,0,0,0.6)', justifyContent: 'flex-end' },
  modalCard: { backgroundColor: '#14141C', borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 20, maxHeight: '85%' },
  modalHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 },
  modalTitle: { color: '#fafafa', fontSize: 17, fontWeight: '700' },
  label: { color: '#a1a1aa', fontSize: 12, marginBottom: 6, marginTop: 6 },
  input: { backgroundColor: 'rgba(255,255,255,0.06)', borderRadius: 12, paddingHorizontal: 14, paddingVertical: 12, color: '#fafafa', fontSize: 15 },
  modalFooter: { flexDirection: 'row', gap: 12, marginTop: 16 },
  footerBtn: { flex: 1, paddingVertical: 14, borderRadius: 14, alignItems: 'center' },
  footerBtnText: { color: '#fff', fontWeight: '700' },
  footerBtnTextMuted: { color: '#a1a1aa', fontWeight: '600' },
  importHints: { flexDirection: 'row', alignItems: 'center', marginBottom: 12, gap: 10 },
  hintChip: { flexDirection: 'row', alignItems: 'center', backgroundColor: 'rgba(139,92,246,0.2)', paddingHorizontal: 12, paddingVertical: 8, borderRadius: 20, gap: 6 },
  hintChipText: { color: '#c4b5fd', fontSize: 13, fontWeight: '600' },
  hintInfo: { flex: 1 },
  hintInfoText: { color: '#52525b', fontSize: 11, lineHeight: 16 },
  exportRow: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: 'rgba(255,255,255,0.06)' },
  exportLabel: { color: '#fafafa', fontSize: 15, fontWeight: '600' },
  exportDesc: { color: '#71717a', fontSize: 12, marginTop: 2 },
  exportTip: { color: '#52525b', fontSize: 11, marginTop: 16, textAlign: 'center' },
  audioRow: { flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: 'rgba(255,255,255,0.04)', borderRadius: 12, padding: 12, marginBottom: 16 },
  audioName: { color: '#d4d4d8', flex: 1, fontSize: 13 },
  dirRow: { flexDirection: 'row', gap: 10, marginBottom: 14 },
  dirBtn: { flex: 1, alignItems: 'center', paddingVertical: 12, borderRadius: 12, backgroundColor: 'rgba(255,255,255,0.05)' },
  dirText: { color: '#d4d4d8', fontWeight: '600' },
  offsetTip: { color: '#71717a', fontSize: 12, marginTop: 12, lineHeight: 18 },
});