import React, { useCallback, useState } from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  Modal,
  StyleSheet,
  TextInput,
  Alert,
} from 'react-native';
import { useFocusEffect } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { Screen } from '@/components/Screen';
import { useSafeRouter } from '@/hooks/useSafeRouter';
import type { Project } from '@/utils/types';
import { makeProject } from '@/utils/types';
import { loadProjects, saveProject, deleteProject } from '@/utils/projectStore';
import { msToString } from '@/utils/timeUtil';
import { parseLyrics } from '@/utils/lrcUtil';
import { readClipboard } from '@/utils/exportUtil';

const ACCENT = '#8B5CF6';

export default function HomeScreen() {
  const router = useSafeRouter();
  const insets = useSafeAreaInsets();
  const [projects, setProjects] = useState<Project[]>([]);
  const [textModal, setTextModal] = useState(false);
  const [text, setText] = useState('');

  useFocusEffect(
    useCallback(() => {
      loadProjects().then(setProjects);
    }, [])
  );

  const open = (p: Project) => router.push('/editor', { projectId: p.id });

  const createNew = async () => {
    const p = makeProject();
    await saveProject(p);
    setProjects((s) => [p, ...s]);
    router.push('/editor', { projectId: p.id });
  };

  const createFromText = async () => {
    if (!text.trim()) return;
    const { lines, meta } = parseLyrics(text);
    if (lines.length === 0) { Alert.alert('提示', '未解析出歌词'); return; }
    const p = makeProject();
    p.lines = lines;
    p.meta = { ...p.meta, ...meta };
    await saveProject(p);
    setTextModal(false);
    setText('');
    router.push('/editor', { projectId: p.id });
  };

  const pasteClip = async () => {
    const t = await readClipboard();
    if (t) setText(t);
    else Alert.alert('提示', '剪贴板为空');
  };

  const remove = (p: Project) => {
    Alert.alert('删除工程', `删除「${p.meta.title || p.audioName || '未命名'}」？`, [
      { text: '取消', style: 'cancel' },
      { text: '删除', style: 'destructive', onPress: async () => { const list = await deleteProject(p.id); setProjects(list); } },
    ]);
  };

  return (
    <Screen safeAreaEdges={['left', 'right', 'bottom']}>
      <View className="bg-background" style={{ flex: 1 }}>
        {/* 顶部 hero */}
        <View style={[styles.hero, { paddingTop: insets.top + 16 }]}>
          <Text style={styles.logo}>歌词打轴</Text>
          <Text style={styles.slogan}>边听边点 · 逐字校准 · 一稿多格式导出</Text>
        </View>

        <FlatList
          data={projects}
          keyExtractor={(p) => p.id}
          contentContainerStyle={{ padding: 16, paddingBottom: 120 }}
          style={{ flex: 1 }}
          renderItem={({ item }) => (
            <TouchableOpacity style={styles.card} onPress={() => open(item)} onLongPress={() => remove(item)} activeOpacity={0.7}>
              <View style={styles.cardIcon}>
                <Ionicons name="musical-notes" size={22} color="#c4b5fd" />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.cardTitle} numberOfLines={1}>
                  {item.meta.title || item.audioName || '未命名工程'}
                </Text>
                <Text style={styles.cardSub} numberOfLines={1}>
                  {[item.meta.artist, item.meta.album].filter(Boolean).join(' · ')}
                  {item.lines.length ? ` · ${item.lines.length} 行` : ''}
                </Text>
                <Text style={styles.cardMeta}>
                  {item.audioDuration ? msToString(item.audioDuration, false) : '未导入音频'}
                  {item.lines.some((l) => l.start >= 0) ? ' · 已打点' : ''}
                </Text>
              </View>
              <Ionicons name="chevron-forward" size={18} color="#52525b" />
            </TouchableOpacity>
          )}
          ListEmptyComponent={
            <View style={{ padding: 40, alignItems: 'center' }}>
              <Ionicons name="musical-notes-outline" size={48} color="#3f3f46" />
              <Text style={styles.empty1}>还没有工程</Text>
              <Text style={styles.empty2}>点下方「新建」开始，或从粘贴歌词快速开始</Text>
            </View>
          }
        />

        {/* 底部操作 */}
        <View style={styles.lowerBar}>
          <TouchableOpacity style={[styles.bottomBtn, styles.textBtn]} onPress={() => setTextModal(true)}>
            <Ionicons name="clipboard-outline" size={18} color="#a78bfa" />
            <Text style={styles.textBtnText}>粘贴歌词</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.bottomBtn, styles.newBtn]} onPress={createNew}>
            <Ionicons name="add" size={22} color="#fff" />
            <Text style={styles.newBtnText}>新建工程</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.bottomBtn, styles.textBtn]} onPress={() => router.push('/settings')}>
            <Ionicons name="settings-outline" size={18} color="#a78bfa" />
            <Text style={styles.textBtnText}>设置</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* 从文本新建 */}
      <Modal visible={textModal} transparent animationType="slide" onRequestClose={() => setTextModal(false)}>
        <View style={styles.mask}>
          <View style={styles.modalCard}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>从歌词文本新建</Text>
              <TouchableOpacity onPress={() => setTextModal(false)}><Ionicons name="close" size={22} color="#a1a1aa" /></TouchableOpacity>
            </View>
            <TouchableOpacity style={styles.clipBtn} onPress={pasteClip}>
              <Ionicons name="clipboard-outline" size={14} color="#c4b5fd" />
              <Text style={styles.clipText}>从剪贴板粘贴</Text>
            </TouchableOpacity>
            <TextInput
              style={[styles.input, { minHeight: 220, textAlignVertical: 'top' }]}
              value={text}
              onChangeText={setText}
              multiline
              placeholder={'粘贴 LRC / SRT / 纯文本歌词…'}
              placeholderTextColor="#52525b"
            />
            <View style={styles.modalFooter}>
              <TouchableOpacity style={[styles.btn, { backgroundColor: 'rgba(255,255,255,0.08)' }]} onPress={() => setTextModal(false)}>
                <Text style={styles.btnMuted}>取消</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.btn, { backgroundColor: ACCENT }]} onPress={createFromText}>
                <Text style={styles.btnPrimary}>创建并打轴</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </Screen>
  );
}

const styles = StyleSheet.create({
  hero: { paddingHorizontal: 20, paddingTop: 40, paddingBottom: 18 },
  logo: { color: '#fafafa', fontSize: 28, fontWeight: '800', letterSpacing: 0.5 },
  slogan: { color: '#71717a', marginTop: 4, fontSize: 13 },
  card: { flexDirection: 'row', alignItems: 'center', backgroundColor: 'rgba(255,255,255,0.03)', borderRadius: 16, padding: 14, marginBottom: 10, gap: 12 },
  cardIcon: { width: 44, height: 44, borderRadius: 12, backgroundColor: 'rgba(139,92,246,0.18)', alignItems: 'center', justifyContent: 'center' },
  cardTitle: { color: '#fafafa', fontSize: 16, fontWeight: '700' },
  cardSub: { color: '#9ca3af', fontSize: 13, marginTop: 3 },
  cardMeta: { color: '#52525b', fontSize: 11, marginTop: 3, fontVariant: ['tabular-nums'] },
  empty1: { color: '#71717a', marginTop: 16, fontSize: 16, fontWeight: '600' },
  empty2: { color: '#3f3f46', marginTop: 8, fontSize: 13, textAlign: 'center', lineHeight: 20 },
  lowerBar: { position: 'absolute', left: 16, right: 16, bottom: 16, flexDirection: 'row', gap: 10 },
  bottomBtn: { flex: 1, paddingVertical: 15, borderRadius: 16, alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 6 },
  newBtn: { backgroundColor: ACCENT, shadowColor: ACCENT, shadowOpacity: 0.4, shadowRadius: 16, shadowOffset: { width: 0, height: 6 }, elevation: 8 },
  newBtnText: { color: '#fff', fontWeight: '700', fontSize: 15 },
  textBtn: { backgroundColor: 'rgba(255,255,255,0.06)' },
  textBtnText: { color: '#c4b5fd', fontWeight: '600', fontSize: 13 },
  mask: { flex: 1, backgroundColor: 'rgba(0,0,0,0.6)', justifyContent: 'flex-end' },
  modalCard: { backgroundColor: '#14141C', borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 20 },
  modalHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 },
  modalTitle: { color: '#fafafa', fontSize: 17, fontWeight: '700' },
  clipBtn: { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: 'rgba(139,92,246,0.2)', alignSelf: 'flex-start', paddingHorizontal: 12, paddingVertical: 8, borderRadius: 20, marginBottom: 12 },
  clipText: { color: '#c4b5fd', fontSize: 13, fontWeight: '600' },
  input: { backgroundColor: 'rgba(255,255,255,0.06)', borderRadius: 12, padding: 14, color: '#fafafa', fontSize: 15 },
  modalFooter: { flexDirection: 'row', gap: 12, marginTop: 16 },
  btn: { flex: 1, paddingVertical: 14, borderRadius: 14, alignItems: 'center' },
  btnMuted: { color: '#a1a1aa', fontWeight: '600' },
  btnPrimary: { color: '#fff', fontWeight: '700' },
});