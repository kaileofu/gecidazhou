// 时间工具：毫秒 <-> LRC/SRT/ASS 时间码格式化与解析

/** 毫秒 -> mm:ss.cc（LRC 风格，百分位） */
export function msToLrc(ms: number): string {
  const v = Math.max(0, Math.round(ms));
  const m = Math.floor(v / 60000);
  const s = Math.floor((v % 60000) / 1000);
  const c = Math.floor((v % 1000) / 10);
  return `${pad2(m)}:${pad2(s)}.${pad2(c)}`;
}

/** 毫秒 -> hh:mm:ss,mmm（SRT 风格，千分位） */
export function msToSrt(ms: number): string {
  const v = Math.max(0, Math.round(ms));
  const h = Math.floor(v / 3600000);
  const m = Math.floor((v % 3600000) / 60000);
  const s = Math.floor((v % 60000) / 1000);
  const mm = Math.floor(v % 1000);
  return `${pad2(h)}:${pad2(m)}:${pad2(s)},${pad3(mm)}`;
}

/** 毫秒 -> hh:mm:ss.cc（ASS 风格） */
export function msToAss(ms: number): string {
  const v = Math.max(0, Math.round(ms));
  const h = Math.floor(v / 3600000);
  const m = Math.floor((v % 3600000) / 60000);
  const s = Math.floor((v % 60000) / 1000);
  const c = Math.floor((v % 1000) / 10);
  return `${pad2(h)}:${pad2(m)}:${pad2(s)}.${pad2(c)}`;
}

/** 毫秒 -> 可读 mm:ss 或 mm:ss.cc（界面显示用） */
export function msToString(ms: number, withCenti = true): string {
  if (ms < 0) return '--:--';
  const v = Math.round(ms);
  const m = Math.floor(v / 60000);
  const s = Math.floor((v % 60000) / 1000);
  if (!withCenti) return `${pad2(m)}:${pad2(s)}`;
  const c = Math.floor((v % 1000) / 10);
  return `${pad2(m)}:${pad2(s)}.${pad2(c)}`;
}

/** 解析 LRC 的 mm:ss.xx 或 mm:ss 时间码，返回毫秒 */
export function parseTimeCode(token: string): number | null {
  const m = /(\d{1,2}):(\d{1,2})(?:[.:](\d{1,3}))?/.exec(token.trim());
  if (!m) return null;
  const min = parseInt(m[1], 10);
  const sec = parseInt(m[2], 10);
  let frac = 0;
  if (m[3]) {
    // 按位数转成毫秒
    const digits = m[3].padEnd(3, '0').slice(0, 3);
    frac = parseInt(digits, 10);
  }
  return min * 60000 + sec * 1000 + frac;
}

/** 解析 LRC 的 <mm:ss.xx> 增强词时间码 */
export function parseEnhancedTime(token: string): number | null {
  const m = /<(\d{1,2}):(\d{1,2})(?:[.:](\d{1,3}))?>/.exec(token);
  if (!m) return null;
  return parseTimeCode(`${m[1]}:${m[2]}.${m[3] ?? '00'}`);
}

function pad2(n: number): string {
  return n < 10 ? '0' + n : '' + n;
}
function pad3(n: number): string {
  return n < 10 ? '00' + n : n < 100 ? '0' + n : '' + n;
}

/** 智能分割歌词文本为「字/词」块（用于逐字打轴）：
 *  中文/日文等 CJK 逐字，拉丁/数字按空格与标点切词 */
export function splitSegments(text: string): string[] {
  const clean = (text ?? '').replace(/\s+/g, ' ').trim();
  if (!clean) return [];
  const CJK = /[\u4e00-\u9fff\u3040-\u30ff\uac00-\ud7af\uff00-\uffef\u3000-\u303f]/;
  const out: string[] = [];
  // 按语义切块：CJK 连续字符合成字串块；非 CJK 按空白/标点分词
  const re = /[\u4e00-\u9fff\u3040-\u30ff\uac00-\ud7af]+|[^\u4e00-\u9fff\u3040-\u30ff\uac00-\ud7af]+/g;
  const parts = clean.match(re) ?? [];
  for (const part of parts) {
    if (CJK.test(part)) {
      // 中文：整段按字再细拆（逐字）
      for (const ch of part) out.push(ch);
    } else {
      // 其它语言：按空白分词
      const words = part.split(/\s+/).filter(Boolean);
      for (const w of words) out.push(w.trim());
    }
  }
  return out.filter(Boolean);
}