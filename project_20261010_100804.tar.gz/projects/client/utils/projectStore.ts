// 本地存储：项目持久化 + 设置（基于 AsyncStorage，三端通用）
import AsyncStorage from '@react-native-async-storage/async-storage';
import type { Project } from './types';

const PROJECTS_KEY = 'lyric_projects_v1';
const ORDER_KEY = 'lyric_projects_order_v1';
export const SETTINGS_KEY = 'lyric_settings_v1';

export interface AppSettings {
  theme: 'system' | 'light' | 'dark';
  fontSize: number; // 歌词字号
  autoAdvance: boolean; // 打点后自动跳转下一未打行
  waveform: boolean; // 显示波形
}

export const defaultSettings: AppSettings = {
  theme: 'dark',
  fontSize: 20,
  autoAdvance: true,
  waveform: true,
};

// ---------- 项目 ----------
export async function loadProjects(): Promise<Project[]> {
  try {
    const raw = await AsyncStorage.getItem(PROJECTS_KEY);
    if (!raw) return [];
    return JSON.parse(raw) as Project[];
  } catch {
    return [];
  }
}

export async function loadProjectById(id: string): Promise<Project | null> {
  const list = await loadProjects();
  return list.find((p) => p.id === id) ?? null;
}

export async function saveProject(project: Project): Promise<Project[]> {
  const list = await loadProjects();
  const idx = list.findIndex((p) => p.id === project.id);
  project.updatedAt = Date.now();
  if (idx >= 0) list[idx] = project;
  else list.unshift(project);
  await AsyncStorage.setItem(PROJECTS_KEY, JSON.stringify(list));
  return list;
}

/** 批量保存（用于撤销/重做时整体覆盖） */
export async function saveProjects(list: Project[]): Promise<void> {
  await AsyncStorage.setItem(PROJECTS_KEY, JSON.stringify(list));
}

export async function deleteProject(id: string): Promise<Project[]> {
  const list = await loadProjects();
  const next = list.filter((p) => p.id !== id);
  await AsyncStorage.setItem(PROJECTS_KEY, JSON.stringify(next));
  return next;
}

// ---------- 设置 ----------
export async function loadSettings(): Promise<AppSettings> {
  try {
    const raw = await AsyncStorage.getItem(SETTINGS_KEY);
    if (!raw) return { ...defaultSettings };
    return { ...defaultSettings, ...JSON.parse(raw) };
  } catch {
    return { ...defaultSettings };
  }
}

export async function persistSettings(s: AppSettings): Promise<void> {
  await AsyncStorage.setItem(SETTINGS_KEY, JSON.stringify(s));
}