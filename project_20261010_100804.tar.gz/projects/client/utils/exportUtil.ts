// 导出 & 分享：写入临时文件并使用系统分享
import * as FileSystem from 'expo-file-system/legacy';
import * as Sharing from 'expo-sharing';
import * as Clipboard from 'expo-clipboard';

/**
 * 将文本写入文件并调起系统分享
 * @param filename 建议文件名（含扩展名）
 * @param content 文本内容
 * @param mimeType MIME 类型
 */
export async function shareTextFile(
  filename: string,
  content: string,
  mimeType = 'text/plain'
): Promise<{ ok: boolean; msg?: string }> {
  try {
    const dir = (FileSystem as any).cacheDirectory || (FileSystem as any).documentDirectory;
    const uri = `${dir}${filename}`;
    await (FileSystem as any).writeAsStringAsync(uri, content, { encoding: 'utf8' });
    if (await Sharing.isAvailableAsync()) {
      await Sharing.shareAsync(uri, { mimeType, dialogTitle: filename });
      return { ok: true };
    }
    // 不支持系统分享时：复制到剪贴板兜底
    await Clipboard.setStringAsync(content);
    return { ok: true, msg: '设备不支持系统分享，已复制到剪贴板' };
  } catch (e) {
    return { ok: false, msg: e instanceof Error ? e.message : '导出失败' };
  }
}

/** 将文本写入剪贴板 */
export async function copyToClipboard(content: string): Promise<boolean> {
  try {
    await Clipboard.setStringAsync(content);
    return true;
  } catch {
    return false;
  }
}

/** 从剪贴板读取文本 */
export async function readClipboard(): Promise<string> {
  try {
    return await Clipboard.getStringAsync();
  } catch {
    return '';
  }
}