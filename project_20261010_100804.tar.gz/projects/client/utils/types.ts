// 歌词项目的核心数据模型

export interface LyricWord {
  text: string;
  /** 词/字的起始时间（毫秒），-1 表示尚未打轴 */
  start: number;
  /** 持续时长（毫秒），可为 -1 */
  duration: number;
}

export interface LyricLine {
  id: string;
  /** 原文（主歌词），单行 */
  text: string;
  /** 翻译（可选），同上行时间轴 / 独立展示 */
  translation: string;
  /** 起始时间（毫秒），-1 表示尚未打轴 */
  start: number;
  /** 逐字时间轴（KTV 用，可选） */
  words: LyricWord[];
  /** 行内偏移（毫秒） */
  lineOffset: number;
}

export interface ProjectMeta {
  title: string;
  artist: string;
  album: string;
  /** 全局偏移（毫秒），正=向后推 */
  offset: number;
}

export interface Project {
  id: string;
  meta: ProjectMeta;
  lines: LyricLine[];
  audioUri?: string;
  audioName?: string;
  audioDuration: number;
  /** 底部滚动到的当前选中行 */
  activeLineId?: string;
  createdAt: number;
  updatedAt: number;
}

export const MAX_STAMP = 100; // 自动打轴时单行允许的最大时长（占歌长比例的保护值）

export function makeLine(text = '', start = -1): LyricLine {
  return {
    id: randomId(),
    text,
    translation: '',
    start,
    words: [],
    lineOffset: 0,
  };
}

export function makeProject(): Project {
  const now = Date.now();
  return {
    id: randomId(),
    meta: { title: '', artist: '', album: '', offset: 0 },
    lines: [],
    audioDuration: 0,
    createdAt: now,
    updatedAt: now,
  };
}

/** 生成设备端随机 id（expo-crypto，兼容三端） */
export function randomId(): string {
  // 动态 require 禁用，这里用全局 Crypto 方式
  if (typeof globalThis !== 'undefined' && (globalThis as any).crypto?.randomUUID) {
    return (globalThis as any).crypto.randomUUID();
  }
  return 'id-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10);
}