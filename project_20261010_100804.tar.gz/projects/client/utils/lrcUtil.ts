// 歌词格式解析与生成：LRC / SRT / 增强 LRC / ASS / TXT
import type { LyricLine, LyricWord, ProjectMeta } from './types';
import { makeLine } from './types';
import { msToLrc, msToSrt } from './timeUtil';

/** 从原始文本解析出歌词工程（含元数据）。返回 { lines, meta } */
export function parseLyrics(
  raw: string,
  preferredFormat: 'auto' | 'lrc' | 'srt' | 'txt' = 'auto'
): { lines: LyricLine[]; meta: Partial<ProjectMeta>; usedFormat: string } {
  const text = (raw ?? '').replace(/\r\n?/g, '\n');
  const meta: Partial<ProjectMeta> = {};

  // 1. 判断格式
  const hasSrt =
    /^\d+[^\S\r\n]*\n[^\S\r\n]*\d{1,2}:\d{2}:\d{2}[,.]\d{1,3}\s*-->\s*\d{1,2}:\d{2}:\d{2}[,.]\d{1,3}/m.test(
      text
    );
  const hasLrc = /\[\d{1,2}:\d{1,2}(?:[.:]\d{1,3})?\]/.test(text);
  const format = preferredFormat !== 'auto' ? preferredFormat : hasSrt ? 'srt' : 'lrc';

  if (format === 'srt') return parseSrt(text, meta);
  return parseLrc(text, meta);
}

export function parseLrc(text: string, meta: Partial<ProjectMeta> = {}): {
  lines: LyricLine[];
  meta: Partial<ProjectMeta>;
  usedFormat: string;
} {
  // 拆成“时间标签+内容”结构
  const re = /((?:\[\d{1,2}:\d{1,2}(?:[.:]\d{1,3})?\])+)(.*)/;
  const lines: LyricLine[] = [];
  const rawRows = text.split('\n');
  let pending: { time: number; rest: string }[] = [];

  const flushPending = () => {
    if (pending.length === 0) return;
    const { rest } = pending[0];
    // 内容里可能残余增强词时间 <mm:ss>，需剥离并用在 words 上
    const pure = rest.replace(/<\d{1,2}:\d{1,2}(?:[.:]\d{1,3})?>/g, '').trim();
    const words: LyricWord[] = [];
    // 提取增强词
    const inlineRe = /<(\d{1,2}:\d{1,2}(?:[.:]\d{1,3})?)>([^<\n]*)/g;
    let m: RegExpExecArray | null;
    while ((m = inlineRe.exec(rest))) {
      const ms = parseLrcTime(m[1]);
      if (ms != null && m[2].trim()) {
        words.push({ text: m[2].trim(), start: ms, duration: -1 });
      }
    }
    if (words.length > 0) {
      // 以第一个词时间为行时间
      const line = makeLine(pure || words.map((w) => w.text).join(''), words[0].start);
      line.words = words;
      lines.push(line);
    } else if (pure) {
      const line = makeLine(pure);
      line.start = pending[0].time;
      lines.push(line);
    }
    pending = [];
  };

  for (const row of rawRows) {
    if (row.trim() === '') {
      flushPending();
      continue;
    }
    // 元数据标签
    const ti = /^\[ti:(.*)\]$/.exec(row.trim());
    const ar = /^\[ar:(.*)\]$/.exec(row.trim());
    const al = /^\[al:(.*)\]$/.exec(row.trim());
    const of = /^\[offset:(.*)\]$/.exec(row.trim());
    if (ti) meta.title = ti[1].trim();
    else if (ar) meta.artist = ar[1].trim();
    else if (al) meta.album = al[1].trim();
    else if (of) meta.offset = parseInt(of[1].trim(), 10) || 0;
    else {
      const mm = re.exec(row.trim());
      if (mm) {
        const tags = mm[1];
        const rest = mm[2];
        const times = (tags.match(/\[\d{1,2}:\d{1,2}(?:[.:]\d{1,3})?\]/g) ?? []).map(parseLrcTime).filter((t): t is number => t != null);
        if (times.length > 0 && (rest.trim() !== '' || pending.length)) {
          flushPending();
          pending = times.map((t) => ({ time: t, rest }));
        }
      } else if (row.trim() && row.trim()[0] !== '[') {
        // 无时间戳的纯文本行：若上一行有时间则作为翻译行
        if (lines.length > 0 && lines[lines.length - 1].translation === '') {
          lines[lines.length - 1].translation = row.trim();
        } else {
          lines.push(makeLine(row.trim()));
        }
      }
    }
  }
  flushPending();
  return { lines, meta, usedFormat: 'lrc' };
}

function parseLrcTime(token: string): number | null {
  const m = /(\d{1,2}):(\d{1,2})(?:[.:](\d{1,3}))?/.exec(token);
  if (!m) return null;
  const min = parseInt(m[1], 10);
  const sec = parseInt(m[2], 10);
  const frac = m[3] ? parseInt(m[3].padEnd(3, '0').slice(0, 3), 10) : 0;
  return min * 60000 + sec * 1000 + frac;
}

function parseSrt(text: string, meta: Partial<ProjectMeta> = {}): {
  lines: LyricLine[];
  meta: Partial<ProjectMeta>;
  usedFormat: string;
} {
  const lines: LyricLine[] = [];
  const blocks = text.split(/\n\s*\n/);
  for (const block of blocks) {
    const rows = block.trim().split('\n');
    if (rows.length < 2) continue;
    const timeRow = rows.find((r) => r.includes('-->'));
    if (!timeRow) continue;
    const parts = timeRow.split('-->');
    const startTok = parts[0].trim();
    // SRT: hh:mm:ss,mmm
    const m = /(\d+):(\d{1,2}):(\d{1,2})[,.](\d{1,3})/.exec(startTok);
    if (!m) continue;
    const start =
      parseInt(m[1], 10) * 3600000 + parseInt(m[2], 10) * 60000 + parseInt(m[3], 10) * 1000 + parseInt(m[4].padEnd(3, '0').slice(0, 3), 10);
    const content = rows.filter((r) => !r.includes('-->') && !/^\d+$/.test(r.trim())).join(' ');
    if (content.trim()) {
      const line = makeLine(content.trim(), start);
      lines.push(line);
    }
  }
  return { lines, meta, usedFormat: 'srt' };
}

/** 导出 LRC（含可选逐字增强） */
export function toLrc(
  lines: LyricLine[],
  meta: Partial<ProjectMeta>,
  opts: { enhanced?: boolean } = {}
): string {
  const out: string[] = [];
  if (meta.title) out.push(`[ti:${meta.title}]`);
  if (meta.artist) out.push(`[ar:${meta.artist}]`);
  if (meta.album) out.push(`[al:${meta.album}]`);
  if (meta.offset) out.push(`[offset:${meta.offset}]`);
  out.push('');
  for (const line of lines) {
    if (line.start < 0 && !line.text) continue;
    const base = line.start >= 0 ? `[${msToLrc(line.start)}]` : '';
    let content = '';
    if (opts.enhanced && line.words && line.words.length > 0) {
      content = line.words
        .map((w) => (w.start >= 0 ? `<${msToLrc(w.start)}>${w.text}` : w.text))
        .join('');
    } else {
      content = line.text;
    }
    if (base || content) {
      let row = `${base}${content}`;
      if (line.translation) row += `\n${base}{t:${line.translation}}`;
      out.push(row);
    }
  }
  return out.join('\n');
}

/** 导出 SRT */
export function toSrt(lines: LyricLine[]): string {
  const out: string[] = [];
  let idx = 1;
  const sorted = lines
    .filter((l) => l.start >= 0)
    .map((l) => ({ ...l, dur: computeDur(l) }))
    .sort((a, b) => a.start - b.start);
  for (const l of sorted) {
    const end = l.start + (l.dur ?? 2000);
    out.push(`${idx}`);
    out.push(`${msToSrt(l.start)} --> ${msToSrt(end)}`);
    out.push(l.text + (l.translation ? `\n${l.translation}` : ''));
    out.push('');
    idx++;
  }
  return out.join('\n');
}

/** 导出 ASS（简化的 Karaoke 简化版，不含复杂特效） */
export function toAss(lines: LyricLine[], meta: Partial<ProjectMeta>): string {
  const { msToAssT } = (() => {
    const f = (ms: number) => {
      const v = Math.max(0, Math.round(ms));
      const h = Math.floor(v / 3600000);
      const m = Math.floor((v % 3600000) / 60000);
      const s = Math.floor((v % 60000) / 1000);
      const c = Math.floor((v % 1000) / 10);
      const pad = (n: number) => (n < 10 ? '0' + n : '' + n);
      return `${pad(h)}:${pad(m)}:${pad(s)}.${pad(c)}`;
    };
    return { msToAssT: f };
  })();
  const header = `[Script Info]
ScriptType: v4.00+
PlayResX: 1920
PlayResY: 1080
WrapStyle: 0
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,Noto Sans CJK SC,60,&H00FFFFFF,&H00FFFFFF,&H00000000,&H80000000,-1,0,0,0,100,100,0,0,1,3,1,2,60,60,40,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text`;
  const events: string[] = [];
  const sorted = lines
    .filter((l) => l.start >= 0)
    .map((l) => ({ ...l, dur: computeDur(l) ?? 2500 }))
    .sort((a, b) => a.start - b.start);
  for (const l of sorted) {
    const end = l.start + l.dur;
    let text = l.text.replace(/\n/g, '\\N');
    if (l.translation) text += '\\N' + l.translation.replace(/\n/g, '\\N');
    events.push(`Dialogue: 0,${msToAssT(l.start)},${msToAssT(end)},Default,,0,0,0,,${text}`);
  }
  return header + '\n' + events.join('\n');
}

/** 导出纯文本 TXT（带或不带时间） */
export function toTxt(lines: LyricLine[], withTime = true): string {
  return lines
    .map((l) => (withTime && l.start >= 0 ? `[${msToLrc(l.start)}] ${l.text}` : l.text))
    .join('\n');
}

/** 计算一行预估时长（用于 SRT/ASS 结束点）：有逐字取最后词 end，否则按字估算 */
function computeDur(l: LyricLine): number | null {
  if (l.words && l.words.length > 0) {
    const last = l.words[l.words.length - 1];
    if (last.start >= 0) return 900;
  }
  return 2500;
}

export { msToSrt };