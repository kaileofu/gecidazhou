import React, { useEffect, useMemo, useRef, useState, memo } from 'react';
import { View, PanResponder, StyleSheet } from 'react-native';
import Svg, { Rect } from 'react-native-svg';

interface Props {
  durationMs: number;
  positionMs: number;
  /** 已打点的时间标记（用于叠加刻度） */
  markers?: { start: number; isSet: boolean }[];
  onSeek?: (ms: number) => void;
  height?: number;
  accentColor?: string;
  markerColor?: string;
}

const BAR_COLOR = '#3b3b47';
const BAR_HI = '#58586a';
const PLAYHEAD = '#F59E0B';

/** 生成一条稳定（随 duration 静态）的伪波形振幅，用于视觉对位辅助 */
function genAmplitude(durationMs: number, count: number): number[] {
  const out: number[] = [];
  let phase = 0;
  const seed = durationMs % 97;
  for (let i = 0; i < count; i++) {
    const t = i / count;
    phase += 0.35 + seed * 0.001;
    const envelope = 0.5 + 0.5 * Math.sin(t * Math.PI * 2 * 3.0 + seed);
    const noise = (Math.sin(phase * 13.37 + seed) * 0.5 + 0.5) * 0.6 + 0.2;
    out.push(Math.min(1, Math.max(0.08, envelope * noise * 1.3)));
  }
  return out;
}

function WaveformViewInner({
  durationMs,
  positionMs,
  markers = [],
  onSeek,
  height = 90,
  accentColor = '#8B5CF6',
  markerColor = '#F59E0B',
}: Props) {
  const [width, setWidth] = useState(0);
  const containerRef = useRef<View>(null);

  // 视图缩放与滚动（用 ref 缓冲 + state 触发重绘）
  const pxPerMsRef = useRef(1);
  const scrollMsRef = useRef(0);
  const [pxPerMs, setPxPerMs] = useState(1);
  const [scrollMs, setScrollMs] = useState(0);

  // 在手势处理器中读取的最新值（ref 避免闭包过期）
  const widthRef = useRef(0);
  const durationRef = useRef(durationMs);
  const onSeekRef = useRef(onSeek);
  useEffect(() => {
    widthRef.current = width;
  }, [width]);
  useEffect(() => {
    durationRef.current = durationMs;
  }, [durationMs]);
  useEffect(() => {
    onSeekRef.current = onSeek;
  }, [onSeek]);

  const gesture = useRef({
    pinchStart: 0,
    scaleStart: 1,
    panStartX: 0,
    scrollStart: 0,
    moved: false,
    touchCount: 1,
  });

  // PanResponder 事件处理器在运行时才访问 ref.current，此处集中管理手势状态
  /* eslint-disable react-hooks/refs */
  const pan = useMemo(() => {
    const clampScroll = () => {
      const w = widthRef.current;
      const dur = durationRef.current;
      if (w <= 0 || dur <= 0) return;
      const contentW = dur * pxPerMsRef.current;
      const max = Math.max(0, contentW - w);
      scrollMsRef.current = Math.min(Math.max(0, scrollMsRef.current), max);
    };
    const sync = () => {
      setPxPerMs(pxPerMsRef.current);
      setScrollMs(scrollMsRef.current);
    };
    return PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onMoveShouldSetPanResponder: () => true,
      onPanResponderGrant: (e) => {
        const touches = e.nativeEvent.touches ?? [e.nativeEvent];
        const g = gesture.current;
        g.touchCount = touches.length;
        g.moved = false;
        g.panStartX = touches[0].pageX;
        g.scrollStart = scrollMsRef.current;
        if (touches.length >= 2) {
          g.pinchStart = Math.hypot(
            touches[1].pageX - touches[0].pageX,
            touches[1].pageY - touches[0].pageY
          );
          g.scaleStart = pxPerMsRef.current;
        }
      },
      onPanResponderMove: (e) => {
        const touches = e.nativeEvent.touches ?? [e.nativeEvent];
        const g = gesture.current;
        const w = widthRef.current;
        const dur = durationRef.current;
        if (w <= 0 || dur <= 0) return;
        const base = w / dur;
        const minPx = base;
        const maxPx = base * 40;
        if (touches.length >= 2) {
          const dist = Math.hypot(
            touches[1].pageX - touches[0].pageX,
            touches[1].pageY - touches[0].pageY
          );
          const ratio = dist / (g.pinchStart || 1);
          pxPerMsRef.current = Math.min(Math.max(g.scaleStart * ratio, minPx), maxPx);
          g.moved = true;
        } else {
          const dx = touches[0].pageX - g.panStartX;
          if (Math.abs(dx) > 4) g.moved = true;
          scrollMsRef.current = g.scrollStart - dx / pxPerMsRef.current;
        }
        clampScroll();
        sync();
      },
      onPanResponderRelease: (e) => {
        const g = gesture.current;
        const dur = durationRef.current;
        if (g.touchCount === 1 && !g.moved) {
          const x = e.nativeEvent.locationX;
          const ms = scrollMsRef.current + x / pxPerMsRef.current;
          onSeekRef.current?.(Math.max(0, Math.min(ms, dur)));
        }
        clampScroll();
        sync();
      },
      onPanResponderTerminate: () => {
        clampScroll();
        sync();
      },
    });
  }, []);
  /* eslint-enable react-hooks/refs */

  const amplitude = useMemo(
    () => genAmplitude(durationMs, Math.max(1, Math.round((width || 360) / 3))),
    [durationMs, width]
  );

  const onLayout = (e: any) => {
    const w = e.nativeEvent.layout.width;
    setWidth(w);
    widthRef.current = w;
    if (w > 0 && durationMs > 0) {
      pxPerMsRef.current = w / durationMs;
      setPxPerMs(pxPerMsRef.current);
      const contentW = durationMs * pxPerMsRef.current;
      const max = Math.max(0, contentW - w);
      if (scrollMsRef.current > max) scrollMsRef.current = max;
      setScrollMs(scrollMsRef.current);
    }
  };

  const visualW = durationMs * pxPerMs;
  const visualH = height;
  // 波形条：基于自然坐标（整歌宽度）绘制，随视觉缩放
  const bars = useMemo(() => {
    const pad = 1;
    if (width <= 0 || durationMs <= 0) return [];
    const basePx = width / durationMs;
    const barW = Math.max(1, basePx * 1.1 - pad);
    const nodes = [];
    for (let i = 0; i < amplitude.length; i++) {
      const barH = Math.max(2, amplitude[i] * (visualH - 8));
      const x = (i / amplitude.length) * width;
      nodes.push(
        <Rect
          key={i}
          x={x}
          y={(visualH - barH) / 2}
          width={barW * (basePx * 1.1 > 1 ? 1 : 0.7)}
          height={barH}
          rx={1}
          fill={i % 3 === 0 ? BAR_HI : BAR_COLOR}
        />
      );
    }
    return nodes;
  }, [amplitude, width, durationMs, visualH]);

  // 播放头位置（像素）
  const playX = (positionMs - scrollMs) * pxPerMs;

  // 行起点刻度
  const markerNodes = useMemo(() => {
    if (!markers || markers.length === 0) return [];
    return markers
      .map((m, i) => {
        const x = (m.start - scrollMs) * pxPerMs;
        if (x < 0 || x > width) return null;
        return (
          <View
            key={i}
            pointerEvents="none"
            style={[
              styles.marker,
              { left: x - 0.5, backgroundColor: m.isSet ? markerColor : '#6b6b78' },
            ]}
          />
        );
      })
      .filter(Boolean);
  }, [markers, scrollMs, pxPerMs, width, markerColor]);

  if (width === 0) {
    return (
      <View
        ref={containerRef}
        onLayout={onLayout}
        style={{ height, overflow: 'hidden' }}
      />
    );
  }

  return (
    <View
      ref={containerRef}
      style={{ height, overflow: 'hidden' }}
      {...pan.panHandlers}
      onLayout={onLayout}
    >
      {/* 波形主体：视觉缩放 */}
      <Svg
        width={Math.max(width, visualW)}
        height={visualH}
        style={[
          styles.svg,
          {
            transform: [{ translateX: -scrollMs * pxPerMs }, { scaleX: pxPerMs / (width / durationMs) }],
          },
        ]}
      >
        {bars}
      </Svg>
      {/* 行起点刻度 */}
      {markerNodes}
      {/* 播放头 */}
      <View
        pointerEvents="none"
        style={[
          styles.playhead,
          { left: Math.max(0, Math.min(width - 1, playX)) - 0.5 },
        ]}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  svg: { position: 'absolute', left: 0, top: 0 },
  marker: {
    position: 'absolute',
    top: 0,
    bottom: 0,
    width: 1,
  },
  playhead: {
    position: 'absolute',
    top: 0,
    bottom: 0,
    width: 2,
    backgroundColor: PLAYHEAD,
  },
});

export const WaveformView = memo(WaveformViewInner);