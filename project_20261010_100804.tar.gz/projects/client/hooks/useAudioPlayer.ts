// 音频播放控制器（基于 expo-av，支持变速、后台播放、进度回调）
import { useEffect, useRef, useState, useCallback } from 'react';
import { Audio } from 'expo-av';

// 吞掉容错的空 catch，避免空的箭头函数体
const silentError = (e: unknown) => {
  if (__DEV__) console.debug('[audio]', e);
};

export function useAudioPlayer() {
  const soundRef = useRef<Audio.Sound | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [position, setPosition] = useState(0);
  const [duration, setDuration] = useState(0);
  const [rate, setRateState] = useState(1);
  const [loadedUri, setLoadedUri] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const rateRef = useRef(rate);
  useEffect(() => {
    rateRef.current = rate;
  }, [rate]);

  // 启动时配置音频模式：支持后台播放、静音键、混音
  useEffect(() => {
    Audio.setAudioModeAsync({
      allowsRecordingIOS: false,
      playsInSilentModeIOS: true,
      staysActiveInBackground: true,
      shouldDuckAndroid: true,
      // interruptionModeIOS / interruptionModeAndroid 使用默认 duck 行为
    }).catch(silentError);
  }, []);

  const unload = useCallback(async () => {
    const s = soundRef.current;
    soundRef.current = null;
    if (s) {
      try {
        await s.unloadAsync();
      } catch {
        // 忽略卸载异常
      }
    }
    setIsPlaying(false);
    setPosition(0);
  }, []);

  const load = useCallback(
    async (uri: string) => {
      if (!uri) return;
      try {
        await unload();
        setIsLoading(true);
        setLoadedUri(uri);
        const { sound } = await Audio.Sound.createAsync(
          { uri },
          { shouldPlay: false, isLooping: false },
          (status) => {
            if (!status.isLoaded) return;
            setPosition(status.positionMillis);
            if (status.durationMillis) setDuration(status.durationMillis);
            setIsPlaying(status.isPlaying);
          }
        );
        soundRef.current = sound;
        await sound.setProgressUpdateIntervalAsync(250).catch(silentError);
        if (rateRef.current !== 1) {
          await sound.setRateAsync(rateRef.current, true, undefined).catch(silentError);
        }
        setIsLoading(false);
      } catch (e) {
        console.error('load audio failed', e);
        setIsLoading(false);
        setLoadedUri(null);
      }
    },
    [unload]
  );

  const play = useCallback(async () => {
    const s = soundRef.current;
    if (!s) return;
    if (rateRef.current !== 1) {
      await s.setRateAsync(rateRef.current, true, undefined).catch(silentError);
    }
    await s.playAsync();
  }, []);

  const pause = useCallback(async () => {
    const s = soundRef.current;
    if (!s) return;
    await s.pauseAsync();
  }, []);

  const toggle = useCallback(async () => {
    if (isPlaying) await pause();
    else await play();
  }, [isPlaying, play, pause]);

  const seek = useCallback(async (ms: number) => {
    const s = soundRef.current;
    if (!s) return;
    const target = Math.max(0, ms);
    setPosition(target);
    await s.setPositionAsync(target);
  }, []);

  const setRate = useCallback(
    async (r: number) => {
      setRateState(r);
      rateRef.current = r;
      const s = soundRef.current;
      if (s) {
        await s.setRateAsync(r, true, undefined).catch(silentError);
      }
    },
    []
  );

  useEffect(() => {
    return () => {
      const s = soundRef.current;
      if (s) s.unloadAsync().catch(silentError);
    };
  }, []);

  return {
    loadedUri,
    isLoading,
    isPlaying,
    position,
    duration,
    rate,
    load,
    unload,
    play,
    pause,
    toggle,
    seek,
    setRate,
  };
}