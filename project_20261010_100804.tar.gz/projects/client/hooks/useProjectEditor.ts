// 工程编辑逻辑：管理 lines 的不可变更新 + 撤销/重做快照
import { useCallback, useRef, useState } from 'react';
import type { LyricLine } from '@/utils/types';

export interface HistoryFrame {
  lines: LyricLine[];
  activeLineId?: string;
}

interface UseProjectEditorReturn {
  lines: LyricLine[];
  pastCount: number;
  futureCount: number;
  /** 异步加载工程后重置初始行（清空历史） */
  reset: (initialLines: LyricLine[]) => void;
  /** 执行一个会改变 lines 的更新，自动 push 快照 */
  commit: (updater: (lines: LyricLine[]) => LyricLine[]) => void;
  undo: () => void;
  redo: () => void;
}

export function useProjectEditor(initialLines: LyricLine[]): UseProjectEditorReturn {
  const [lines, setLines] = useState<LyricLine[]>(initialLines);
  const pastRef = useRef<HistoryFrame[]>([]);
  const futureRef = useRef<HistoryFrame[]>([]);
  const [pastCount, setPastCount] = useState(0);
  const [futureCount, setFutureCount] = useState(0);

  const sync = useCallback(() => {
    setPastCount(pastRef.current.length);
    setFutureCount(futureRef.current.length);
  }, []);

  const reset = useCallback((initial: LyricLine[]) => {
    pastRef.current = [];
    futureRef.current = [];
    setLines(initial);
    sync();
  }, [sync]);

  const commit = useCallback((updater: (lines: LyricLine[]) => LyricLine[]) => {
    pastRef.current = [...pastRef.current.slice(-49), { lines }];
    futureRef.current = [];
    setLines((cur) => updater(cur));
    sync();
  }, [lines, sync]);

  const undo = useCallback(() => {
    const past = pastRef.current;
    if (past.length === 0) return;
    const frame = past[past.length - 1];
    pastRef.current = past.slice(0, -1);
    futureRef.current = [...futureRef.current, { lines }];
    setLines(frame.lines);
    sync();
  }, [lines, sync]);

  const redo = useCallback(() => {
    const future = futureRef.current;
    if (future.length === 0) return;
    const frame = future[future.length - 1];
    futureRef.current = future.slice(0, -1);
    pastRef.current = [...pastRef.current, { lines }];
    setLines(frame.lines);
    sync();
  }, [lines, sync]);

  return { lines, pastCount, futureCount, reset, commit, undo, redo };
}