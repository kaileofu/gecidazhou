import { createContext, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { Uniwind } from 'uniwind';
import { loadSettings, persistSettings, type AppSettings } from '@/utils/projectStore';

interface SettingsContextValue {
  settings: AppSettings;
  isDark: boolean;
  update: (patch: Partial<AppSettings>) => Promise<void>;
}

const SettingsContext = createContext<SettingsContextValue | null>(null);

export function SettingsProvider({ children }: { children: ReactNode }) {
  const [settings, setSettings] = useState<AppSettings>({
    theme: 'dark',
    fontSize: 20,
    autoAdvance: true,
    waveform: true,
  });
  const [ready, setReady] = useState(false);
  const latest = useRef(settings);
  useEffect(() => {
    latest.current = settings;
  }, [settings]);

  useEffect(() => {
    (async () => {
      const s = await loadSettings();
      setSettings(s);
      setReady(true);
    })();
  }, []);

  // 应用主题
  useEffect(() => {
    try {
      Uniwind.setTheme(settings.theme);
    } catch {
      /* ignore */
    }
  }, [settings.theme]);

  const isDark = useMemo(() => {
    if (settings.theme === 'dark') return true;
    if (settings.theme === 'light') return false;
    return true; // system 默认按深色工台展示
  }, [settings.theme]);

  const update = async (patch: Partial<AppSettings>) => {
    const next = { ...latest.current, ...patch };
    setSettings(next);
    await persistSettings(next);
  };

  return (
    <SettingsContext.Provider value={{ settings, isDark, update }}>
      {children}
    </SettingsContext.Provider>
  );
}

export function useSettings(): SettingsContextValue {
  const ctx = useContext(SettingsContext);
  if (!ctx) throw new Error('useSettings must be used within SettingsProvider');
  return ctx;
}